---
title: "Progetto Curva Sud Rojava"
description: "Uno spazio per il gioco e lo sport alla scuola di Kani Kurdan, a Kobane."
weight: 30
draft: false
---

## Raccolta fondi

Per partecipare alla raccolta fondi è possibile versare un contributo sul seguente conto:

- **Intestato a:** Comitato ticinese per la ricostruzione di Kobane
- **Conto corrente postale:** 69-605609-5
- **IBAN:** CH78 0900 0000 6960 5609 5
- **Menzione:** Progetto Curva Sud Rojava

## Stato del progetto

I lavori per la costruzione dello spazio giochi e sportivo sono quasi ultimati!

Qui sotto una fotografia arrivata direttamente dalla scuola elementare di Kani Kurdan, un quartiere a nord-est di Kobane.

![Lo spazio giochi e sportivo quasi ultimato](campo_kobane.jpg)

Questa fotografia mostra invece una fase dei lavori.

![Lo spazio giochi e sportivo durante i lavori](lavori_kobane.jpg)

Continueremo a tenervi informate e informati sull’avanzamento del progetto.

## Scopo del progetto

Il progetto sostiene la realizzazione di uno spazio per il gioco e lo sport presso la scuola elementare di Kani Kurdan, a Kobane, con un campo da calcio, uno da basket e uno da pallavolo.

Crediamo nel ruolo attivo della scuola nella costruzione del confederalismo democratico in Rojava. Per questo abbiamo deciso di contribuire al completamento degli spazi scolastici, sostenendo in particolare la realizzazione delle strutture dedicate al gioco e allo sport.

La scuola ospita circa 2’000 studenti ed è l’unica del quartiere costruita dopo la guerra che ha colpito la città e distrutto le sue infrastrutture. È tuttora priva di attrezzature e campi sportivi.

Considerate le risorse finanziarie limitate, è stato incaricato un comitato di ingegneri di elaborare una valutazione preliminare dei costi. Si è quindi deciso di iniziare dal livellamento del terreno, dalla posa della pavimentazione e dall’installazione delle attrezzature per i tre campi.

## La scuola

Secondo il rapporto del 4 settembre 2018, la costruzione della scuola e la sistemazione del giardino erano state completate. Il Comitato per la ricostruzione di Kobane, insieme al Ministero dell’educazione del cantone di Kobane, ha fornito gli arredi e i materiali necessari allo svolgimento delle lezioni.

La scuola ha aperto nel febbraio 2019 per rispondere alle necessità della popolazione. Le lezioni sono organizzate su due turni, diurno e pomeridiano, per permettere al maggior numero possibile di bambini di frequentare. Gli insegnanti sono 18, in maggioranza donne, e gli studenti iscritti sono circa 2’000.

La realizzazione della scuola è stata sostenuta anche dalle donazioni raccolte in Svizzera attraverso il progetto «Kani Kurdan-Schul für Kobane».

## Il quartiere di Kani Kurdan

Kani Kurdan è uno dei quartieri più poveri di Kobane. Situato a nord-est della città, vicino al confine con la Turchia, è stato pesantemente distrutto durante la guerra e non aveva ricevuto sostegno dai governi precedenti.

Nel quartiere vivono numerose famiglie con risorse economiche limitate e famiglie rifugiate, per le quali l’accesso all’istruzione dei figli rappresenta una difficoltà concreta. La mancanza di scuole ha quindi spinto l’amministrazione cittadina e quella cantonale a concentrare qui una parte dei propri interventi.

Per rispondere alle esigenze immediate, il Ministero dell’istruzione ha inizialmente allestito alcuni container destinati alle lezioni, avviando nel contempo il progetto di una nuova scuola. Attraverso un accordo con i proprietari dei terreni è stata destinata all’istruzione un’area di 2’400 m².

La scuola occupa una superficie di 1’135 m² e comprende un rifugio sotterraneo per proteggere la popolazione in caso di emergenza. Il piano terra e il primo piano ospitano complessivamente otto aule, spazi amministrativi, una cucina, un deposito e sei servizi igienici collegati alla rete fognaria.

I lavori di costruzione sono iniziati nell’aprile 2017 e sono proseguiti nonostante le difficoltà di approvvigionamento dei materiali.

![La scuola di Kani Kurdan a Kobane](kobane.jpeg)
