---
title: "Gaza Web"
description: "Gli alberi della rete."
weight: 20
draft: false
---

# Gaza Web – Alberi della Rete

Il nostro percorso decennale di sostegno alla Palestina ci ha portato a organizzarci per portare un piccolo contributo a un progetto umanitario attivo nella Striscia di Gaza.

Il progetto **Gazaweb – Alberi della Rete** è portato avanti da **A.C.S. – Associazione di Cooperazione e Solidarietà**, una ONG laica e senza scopo di lucro che da oltre 20 anni opera nelle zone critiche del sud del mondo con progetti di emergenza e di sviluppo sostenibile.

---

## Perché Gaza Web è necessario

Il diritto a comunicare è fondamentale per chi si ritrova a sopravvivere all’interno del più grande carcere a cielo aperto della terra.  
Lo Stato di Israele, che da decenni porta avanti un genocidio contro la popolazione palestinese, questo lo sa molto bene.

Ne sono la prova:

- le uccisioni mirate di blogger e giornalisti che hanno provato a raccontare gli abusi dell’esercito di occupazione israeliano  
- i bombardamenti contro infrastrutture di comunicazione: antenne, redazioni, stazioni TV

La comunicazione è vitale:

- per tenere in contatto i membri delle famiglie separati dalle macerie  
- per permettere a bambini e bambine di seguire le lezioni a distanza nonostante la distruzione delle scuole  
- per ricevere informazioni sui punti di distribuzione degli aiuti umanitari  
- per segnalare bombardamenti e zone di evacuazione  

Ma, più semplicemente, la comunicazione è la base della coesione sociale in un contesto di guerra e distruzione inimmaginabile.

L’obiettivo del progetto è quello di rendere accessibile un’infrastruttura di base per garantire tutto questo alla popolazione gazawita, che vive da anni sotto un durissimo embargo imposto dal governo colonialista di Israele.

---

## Approfondimenti

Informazioni più dettagliate sugli aspetti tecnici si trovano nelle pagine ufficiali di presentazione del progetto Gazaweb.  
Da parte nostra, in seguito approfondiremo con articoli all’interno de *Lo Sgambetto*.

---

## Come sosteniamo Gaza Web

Per dare il nostro contributo, mettiamo in vendita una **sciarpa ad offerta libera** (prezzo base 10.–):  
il ricavato sarà interamente devoluto al progetto.

La sciarpa verrà venduta:

- al banchetto della Curva Sud  
- in ulteriori benefit e bancarelle che segnaleremo nel nostro blog di volta in volta  

---

## Raccolta fondi

La raccolta fondi è organizzata tramite l’infrastruttura gestita da **Produzioni dal Basso**.

**Informazioni e donazioni:**  
https://www.produzionidalbasso.com/project/gazaweb-fai-crescere-gli-alberi-della-rete-a-gaza/

Vi chiediamo di **diffondere gli estremi della raccolta fondi** anche al di fuori della Curva Sud, a tutti i vostri possibili contatti.
